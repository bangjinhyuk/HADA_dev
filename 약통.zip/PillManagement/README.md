# PillManagement
HADA development

1. 구성 
    * Android Studio - java,SQLite
    * Bluetooth - 아두이노


2. 기능
    * 먹어야 하는 약 저장
    * 캘린더 뷰를 통해 오늘 약 확인
    * 약 섭취 시간 도달시 알람 
    * 알람 이후 30분 내 블루투스로 섭취 정보 받아오면 실시간으로 섭취로 변경 

    


    
    